package com.example.work02;

public class people{
    private String content;
    public people(String content){
        this.content=content;
    }
    public String getContent(){
        return content;
    }
}
